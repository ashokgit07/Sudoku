java -jar SudokuValidator.jar $1
